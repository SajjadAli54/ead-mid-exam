import React from "react";

import { Card } from "antd";

function ThankYouMessage() {
  return <Card>Thanks for voting</Card>;
}

export default ThankYouMessage;
